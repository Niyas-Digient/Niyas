import { Component, OnInit } from '@angular/core';
import { spinWheel } from './game.animate';
import { resize } from './game.scale';
import { gameOptions } from './game.animate';

import Phaser from 'phaser';

var wheelImg: Phaser.GameObjects.Image;
var tweens;
var spinToggle: Boolean = true;
var wheelContainer;


@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.scss']
})
export class GameComponent implements OnInit {
  phaserGame: Phaser.Game;
  config: Phaser.Types.Core.GameConfig;
  constructor() {
    this.config = {
      type: Phaser.AUTO,
      height: window.innerHeight,
      width: window.innerWidth,
      scene: [MainScene],
      parent: 'gameContainer',
      physics: {
        default: 'arcade',
        arcade: {
          gravity: { y: 100 }
        }
      }
    };
  }

  ngOnInit() {
    this.phaserGame = new Phaser.Game(this.config);
  }
}

class MainScene extends Phaser.Scene {
  constructor() {
    super({ key: 'main' });
  }
  addButton() {
    console.log('this.game = ', this.game);
    var spinButton = this.add.sprite(400, 300, 'spin_button', 1).setInteractive();

    spinButton.setOrigin(0.5, 0.5);
    spinButton.setScale(0.5, 0.5);
    spinButton.setPosition(this.game.canvas.width / 2, this.game.canvas.height / 2);

    spinButton.on('pointerover', function () {
      this.setFrame(2);
    });

    spinButton.on("pointerdown", function () {
      this.setFrame(0);
      if (!spinToggle) return;
      spinToggle = false;
      spinWheel(wheelContainer, tweens, function () {
        spinToggle = true;
      });
    });

    spinButton.on('pointerout', function () {
      this.setFrame(0);
    });
  }
  create() {

    resize(this.game);

    // starting degrees
    let startDegrees = -90;

    // array which will contain all icons
    let iconArray = [];

    // this array will contain the allowed degrees
    let allowedDegrees = [];

    //wheelContainer = this.add.group();
    //wheelContainer = this.add.container(0, 0);
    /* wheelContainer.setPosition(0, 0); */


    let bg: Phaser.GameObjects.Image = this.add.image(0, 0, 'bg');
    wheelContainer = this.add.container(0, 0);
    wheelImg = this.add.image(0, 0, 'wheel');
    let winGlow: Phaser.GameObjects.Image = this.add.image(0, 0, 'win_glow').setOrigin(0.5, 0.5);
    let winFrame: Phaser.GameObjects.Image = this.add.image(0, 0, 'win_frame').setOrigin(0.5, 0.5);
    tweens = this.tweens;

    winFrame.setPosition(this.game.canvas.width / 2, this.game.canvas.height / 2 - 72);
    //wheelImg.setPosition(this.game.canvas.width / 2, this.game.canvas.height / 2);
    //wheelImg.setOrigin(0.5);

    wheelContainer.setPosition(this.game.canvas.width / 2, this.game.canvas.height / 2);
    winGlow.setPosition(this.game.canvas.width / 2, this.game.canvas.height / 2 - 140);
    bg.setPosition(this.game.canvas.width / 2, this.game.canvas.height / 2);

    wheelImg.setScale(0.5, 0.5);
    //wheelContainer.setScale(0.5, 0.5);
    winGlow.setScale(0.5, 0.5);
    bg.setScale(0.5, 0.5);
    winFrame.setScale(0.5, 0.5);
    bg.alpha = 0.6;

    // winGlow.alpha = 0;

    this.addButton();

    /** Text */
    for (let i = 0; i < gameOptions.slicePrizes.length; i++) {


      console.log("length-->", gameOptions.slicePrizes.length);
      // add slice text, if any
      if (gameOptions.slicePrizes[i].sliceText != undefined) {

        // the text
        //let text = this.add.text(gameOptions.wheelRadius * 0.75 * Math.cos(Phaser.Math.DegToRad(startDegrees + gameOptions.slicePrizes[i].degrees / 2)), gameOptions.wheelRadius * 0.75 * Math.sin(Phaser.Math.DegToRad(startDegrees + gameOptions.slicePrizes[i].degrees / 2)), gameOptions.slicePrizes[i].sliceText, gameOptions.slicePrizes[i].sliceTextStyle);

        let text = this.add.text(gameOptions.wheelRadius * 0.75 * Math.cos(Phaser.Math.DegToRad(startDegrees + gameOptions.slicePrizes[i].degrees / 20)), gameOptions.wheelRadius * 0.75 * Math.sin(Phaser.Math.DegToRad(startDegrees + gameOptions.slicePrizes[i].degrees / 20)), gameOptions.slicePrizes[i].sliceText, gameOptions.slicePrizes[i].sliceTextStyle);

        // set text origin to its center
        text.setOrigin(0.5,0);

        // set text angle
        text.angle = startDegrees + gameOptions.slicePrizes[i].degrees + 60;

        // stroke text, if required
        if (gameOptions.slicePrizes[i].sliceTextStroke && gameOptions.slicePrizes[i].sliceTextStrokeColor) {
          text.setStroke(gameOptions.slicePrizes[i].sliceTextStrokeColor, gameOptions.slicePrizes[i].sliceTextStroke);
        }

        // add text to iconArray
        iconArray.push(text);


      }

      wheelContainer.add(wheelImg);
      wheelContainer.add(iconArray);


      // updating degrees
      startDegrees += gameOptions.slicePrizes[i].degrees;
    }

  }
  preload() {
    this.load.image('wheel', 'assets/wheel.png');
    this.load.image('win_glow', 'assets/win_glow.png');
    this.load.image('win_frame', 'assets/win_frame.png');
    this.load.spritesheet('spin_button', 'assets/spin_button.png', { frameWidth: 160, frameHeight: 160 })
    this.load.image('bg', 'assets/bg.jpg');
  }
  update() {
    console.log('update method');
  }
}

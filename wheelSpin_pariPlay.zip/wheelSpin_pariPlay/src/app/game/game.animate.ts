export const gameOptions = {

    // slices (prizes) placed in the wheel
    slices: 10,

    wheelRadius: 230,

    // prize names, starting from 12 o'clock going clockwise
    //slicePrizes: ["A KEY!!!", "50 STARS", "500 STARS", "BAD LUCK!!!", "200 STARS", "100 STARS", "150 STARS", "BAD LUCK!!!"],

    slicePrizes: [
        {
            degrees: 36,
            text: "BANANA",
            enabled: true,
            sliceText: "1",
            sliceTextStyle: {
                fontFamily: "Arial Black",
                fontSize: 36,
                color: "#000077",
                align: "center"
            },
            sliceTextStroke: 8,
            sliceTextStrokeColor: "#ffffff",
        },
        {
            degrees: 36,
            text: "BANANA",
            enabled: true,
            sliceText: "2",
            sliceTextStyle: {
                fontFamily: "Arial Black",
                fontSize: 36,
                color: "#000077",
                align: "center"
            },
            sliceTextStroke: 8,
            sliceTextStrokeColor: "#ffffff",
        },
        {
            degrees: 36,
            text: "BANANA",
            enabled: true,
            sliceText: "3",
            sliceTextStyle: {
                fontFamily: "Arial Black",
                fontSize: 36,
                color: "#000077",
                align: "center"
            },
            sliceTextStroke: 8,
            sliceTextStrokeColor: "#ffffff",
        },

        {
            degrees: 36,
            text: "PEAR",
            enabled: true,
            sliceText: "4",
            sliceTextStyle: {
                fontFamily: "Arial Black",
                fontSize: 36,
                color: "#000077",
                align: "center"
            },
            sliceTextStroke: 8,
            sliceTextStrokeColor: "#ffffff",
        },
        {
            degrees: 36,

            text: "BLUE TEXT, WHITE STROKE",
            sliceText: "5",
            sliceTextStyle: {
                fontFamily: "Arial Black",
                fontSize: 36,
                color: "#000077",
                align: "center"
            },
            sliceTextStroke: 8,
            sliceTextStrokeColor: "#ffffff",
            enabled: false
        },
        {
            degrees: 36,
            text: "STRAWBERRY",
            enabled: true,
            sliceText: "6",
            sliceTextStyle: {
                fontFamily: "Arial Black",
                fontSize: 36,
                color: "#000077",
                align: "center"
            },
            sliceTextStroke: 8,
            sliceTextStrokeColor: "#ffffff",
        },
        {
            degrees: 36,
            text: "POO :(",
            sliceText: "7",
            sliceTextStyle: {
                fontFamily: "Arial Black",
                fontSize: 36,
                color: "#000077",
                align: "center"
            },
            sliceTextStroke: 8,
            sliceTextStrokeColor: "#ffffff",
            enabled: false
        },
        {
            degrees: 36,
            text: "POO :(",
            sliceText: "8",
            sliceTextStyle: {
                fontFamily: "Arial Black",
                fontSize: 36,
                color: "#000077",
                align: "center"
            },
            sliceTextStroke: 8,
            sliceTextStrokeColor: "#ffffff",
            enabled: false
        },
        {
            degrees: 36,
            text: "POO :(",
            sliceText: "9",
            sliceTextStyle: {
                fontFamily: "Arial Black",
                fontSize: 36,
                color: "#000077",
                align: "center"
            },
            sliceTextStroke: 8,
            sliceTextStrokeColor: "#ffffff",
            enabled: false
        },
        {
            degrees: 36,
            text: "POO :(",
            sliceText: "10",
            sliceTextStyle: {
                fontFamily: "Arial Black",
                fontSize: 36,
                color: "#000077",
                align: "center"
            },
            sliceTextStroke: 8,
            sliceTextStrokeColor: "#ffffff",
            enabled: false
        }
    ],

    // wheel rotation duration, in milliseconds
    rotationTime: 10000
}

export const spinWheel = (_param: any, _tween: any, _callback: any) => {
    console.log("1-->", _param, "2-->", _tween, "_callback-->", _callback);
    if (true) {

        // the wheel will spin round from 2 to 4 times. This is just coreography
        var rounds = Phaser.Math.Between(2, 4 );

        // then will rotate by a random number from 0 to 360 degrees. This is the actual spin
        var degrees = Phaser.Math.Between(0, 360);

        // before the wheel ends spinning, we already know the prize according to "degrees" rotation and the number of slices
        var prize = gameOptions.slices - 1 - Math.floor(degrees / (360 / gameOptions.slices));

        // now the wheel cannot spin because it's already spinning
        //this.canSpin = false;

        // animation tweeen for the spin: duration 3s, will rotate by (360 * rounds + degrees) degrees
        // the quadratic easing will simulate friction
        _tween.add({

            // adding the wheel to tween targets
            targets: [_param],

            // angle destination
            angle: 360 * rounds + degrees,

            // tween duration
            duration: gameOptions.rotationTime - 360 ,

            // tween easing
            ease: "Cubic.easeOut",

            // callback scope
            callbackScope: this,

            // function to be executed once the tween has been completed
            onComplete: function (tween) {
                _callback();
                console.log("win res-->", gameOptions.slicePrizes[prize]);
                // player can spin again
                //this.canSpin = true;
            }
        });
    }

}